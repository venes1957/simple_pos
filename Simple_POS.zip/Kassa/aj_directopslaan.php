<?php

$product=filter_input(INPUT_POST, "product");

//directOpslaan

require_once('cl_bonhandling.php');
$testObject = new cl_bonhandling();
$testObject->directOpslaan($product,"Direct");
