<?php

/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Scripting/PHPClass.php to edit this template
 */

/**
 * Description of filehandling
 *
 * @author Jos Venes
 */
class cl_filehandling {

//put your code here
    function laadFile($filenaam) {
        $lines = array();
        $fp = fopen($filenaam, 'r');
        while (!feof($fp)) {
            $line = fgets($fp);

            //process line however you like
            $line = trim($line);

            //add to array
            $lines[] = $line;
        }
        fclose($fp);
        $lines = array_filter($lines); //lege elementen verwijderen
        return $lines;
    }
    function filterarrayProduct($array, $filter) {
//    filter = "Hertog Jan Bier";
 
        $new_array = array_filter($array, function ($var) use ($filter) {
            return ($var[3] == $filter);
        });

        return $new_array;
    }

    function csv_to_multidimension_array($filename, $delimiter) {
        if (!file_exists($filename) || !is_readable($filename)) {

            //===============
            $fp = fopen($filename, 'a');
            fwrite($fp, "" . "\r\n");
            fclose($fp);

            ///=================
            return false;
        }

//    $header = NULL;
        $data = array();

        if (($handle = fopen($filename, 'r')) !== false) {
            while (($row = fgetcsv($handle, 1000, $delimiter)) !== false) {
                $data[] = $row;
            }
            fclose($handle);
        }
        return $data;
    }

}

//$req_dump = print_r($_REQUEST, TRUE);
//$fp = fopen('request.log', 'a');
//fwrite($fp, $req_dump);
//fclose($fp);

