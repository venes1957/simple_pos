<?php

 
$naam = $_POST['naam'];  //$data will contain the_id
//$naam='barcoach';
$filename="bonnen/".$naam.".txt";
//echo $filename;

$tabel = "<div id='grd1'";
$tabel = "<h1 class='bon' id='naam'></h1>";
$tabel .= "<table class='w3-table w3-striped w3-border' id='xbon'>";
$tabel .= "<th><tr><th>Aantal</th><th>Prijs</th><th>Product</th><th>Bedrag</th><td>Del</td></tr>";
$totaal = 0;
$telop = 0;
$teller=0;

foreach (file($filename) as $line) {
    $teller++;
    $eenbon = explode(";", $line);
    $tabel .= "<tr><td id='aantal' contenteditable>" . $eenbon[4] . '</td>'; //aantal
    $tabel .= "<td contenteditable id='prijs'>" . $eenbon[5] . '</td>'; //prijs
    $tabel .= "<td contenteditable >" . $eenbon[3] . '</td>'; 
    $tabel .= "<td id='bedrag'>" .$eenbon[6] . '</td>'; //bedrag
    $tabel .= "<td><img class='delete' src='../icons/delete.png'></img></td>"; 
    $totaal += $eenbon[6];
//    $telop += $eenbon[4];
    $tabel .= '</tr>';
}

$tabel .= "<tr id='last'><td>Totaal:&nbsp;</td><td contenteditable id='xsum' style='font-weight: bold;'>" . curr_format($totaal) . "</td></tr>";
//<td>Aantal:&nbsp;</td><td contenteditable id='xaantal'>$telop</td>
$tabel .= "</table></div>";

function curr_format($amount) {
    if ($amount == NULL) {
        return;
    }
    $ret = "€" . number_format($amount, 2, ",", " ");
    return $ret;
}

















//$x=1;
//$script="<script>";
////for ($x=1; $x < ($teller+1); $x++){
//    $script.="document.getElementById(['aantal$x']).onblur=message$x;";
////}
////for ($x=1; $x < ($teller+1); $x++){
//    $script.="function message$x() {";
//    $script.="alert('test');";
//    $script.=" var aantal = document.getElementById('aantal$x').value;";
//    
//    $script.=" var prijs = document.getElementById('prijs$x').value;";
////    $script.=" var aantal = document.getElementById('aantal$x').value;}";
////}
//$script.="</script>";
//
//$req_dump = print_r($_REQUEST, TRUE);
//$fp = fopen('request.log', 'a');
//fwrite($fp, $tabel.$script);
//fclose($fp);

//echo $tabel.$script;

echo $tabel;

//nog testen
//function message() {
//    
//    var aantal = document.getElementById("aantal1").value;
//    var prijs = document.getElementById("prijs1").value;
//       //alert(aantal*prijs);
//           document.getElementById("tot1").value=aantal*prijs;
////    }
//
//document.getElementById(['aantal1']).onblur=message;
//document.getElementById(['aantal2']).onblur=message;
