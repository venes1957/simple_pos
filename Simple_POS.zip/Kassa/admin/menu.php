<?php

/* 
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Scripting/EmptyPHP.php to edit this template
 */
?>
<div class="w3-bar w3-border w3-light-grey"/>
    <a href="\" class="w3-bar-item w3-button">Home</a>
            <a href="bew_product.php" class="w3-bar-item w3-button w3-hover-green">Producten</a>
            <a href="Omzet.php" class="w3-bar-item w3-button w3-hover-green">Omzet per dag</a>
            <a href="Omzet_per_product.php" class="w3-bar-item w3-button w3-hover-green">Omzet per product</a>
            <a href="info.php" class="w3-bar-item w3-button w3-hover-green">Info</a>
<!--            <a href="wedstrijden.php" class="w3-bar-item w3-button w3-hover-blue">Rondes</a>
            <a href="stand.php" class="w3-bar-item w3-button w3-hover-teal">Stand</a>-->
</div>