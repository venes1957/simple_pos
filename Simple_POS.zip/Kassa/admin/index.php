<?php
/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Scripting/EmptyPHP.php to edit this template
 */
?>

<!DOCTYPE html>
<html>
    <title>W3.CSS</title>
    <meta name="viewport" content="width=device-width, initial-scale=1">
    <link rel="stylesheet" href="../css-js/w3.css">
    <script src="../css-js/jquery-3.6.0.js"></script>
    <body>
<?php include "menu.php";?>
        <div class="w3-container">
<!--            <h2>Basic Table</h2>
            <p>The w3-table class defines a basic table:</p>-->

        
    </body>
</html>