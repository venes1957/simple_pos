<?php

/* 
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Scripting/EmptyPHP.php to edit this template
 */

$name= $_GET['naam'];

$filename="product.txt";
$backup="backup.txt";
rename($filename,$backup);
unlink($filename);
file_put_contents($filename, trim($name));
