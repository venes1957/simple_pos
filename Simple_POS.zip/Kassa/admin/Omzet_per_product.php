<?php
$naam = 'Omzet';  //$data will contain the_id
$filename = "../bonnen/" . $naam . ".txt";
$delimeter = ";";
require_once('../cl_filehandling.php');
$testObject = new cl_filehandling();
$array = $testObject->csv_to_multidimension_array($filename, $delimeter);

//===========welke producten zitten er in de sarray
$prods = "";
foreach ($array as $value) {
    $prods .= $value[3] . ";";
}
$prodsX = explode(";", $prods);
$prodsX = array_unique($prodsX);
$producten = array_filter($prodsX); //lege elementen verwijderen

//=========================================sorteer de MD array==================
function aasort(&$array, $key) {
    $sorter = array();
    $ret = array();
    reset($array);
    foreach ($array as $ii => $va) {
        $sorter[$ii] = $va[$key];
    }
    asort($sorter);
    foreach ($sorter as $ii => $va) {
        $ret[$ii] = $array[$ii];
    }
    $array = $ret;
}

aasort($array, 3);

//=============================filer md array!!!!=============================
$aantal = count($producten);
$teller=0;
for ($i = 0; $i < ($aantal); $i++) {
//    echo $producten[$i].":".$i;
$filter=$producten[$i];
//    $array = $testObject->filterarrayProduct($array, $producten[$i]);
      $new_array = array_filter($array, function ($var) use ($filter) {
            return ($var[3] == $filter);
        });

    echo "<pre>";

    print_r($new_array);
//==============================================================================
    $telop = 0;
    $telop2 = 0;
    foreach ($array as $value) {
        $telop += $value[6]; //totaalbedrag
        $telop2 += $value[4]; //aantal
    }
    echo $producten[$i]." : ".$telop2." : ".$telop;
}
?>


<!DOCTYPE html>

<html>
    <head>
        <meta charset="UTF-8">
        <title></title>

        <meta name="viewport" content="width=device-width, initial-scale=1">
        <link rel="stylesheet" href="../css-js/w3.css">
        <script src="../css-js/jquery-3.6.0.js"></script>

        <link rel="stylesheet" href="https://code.jquery.com/ui/1.11.4/themes/smoothness/jquery-ui.css">

        <script src="https://code.jquery.com/ui/1.11.4/jquery-ui.js"></script>  


    </head>
    <body class="">




        <div class="w3-row w3-border">
            <div class="w3-half w3-container">



            </div>

        </div>


    </body>
</html>




