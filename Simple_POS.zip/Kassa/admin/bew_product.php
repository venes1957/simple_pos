<?php
/*

 */
//==========================================================================
$doc_root = $_SERVER["DOCUMENT_ROOT"];
require_once ($doc_root . "/settings.php");
//include(ROOTPATH . '/txtdatabase/txtdb.class.php');
$totaal = 0;
//$telop = 0;
$csv = '';

//============PRODUCTEN==================================================================
$filename = ROOTPATH . "/admin/product.txt";
$delimiter = ";";

function csv_to_multidimension_array($filename = '', $delimiter = ',') {
    if (!file_exists($filename) || !is_readable($filename)) {
        return false;
    }

    $data = array();

    if (($handle = fopen($filename, 'r')) !== false) {
        while (($row = fgetcsv($handle, 1000, $delimiter)) !== false) {
            $data[] = $row;
        }
        fclose($handle);
    }
    return $data;
}
$array = csv_to_multidimension_array($filename, $delimiter);



$tblProd = "<table id='prods' class='w3-table-all' style='width: 70%;'>";
$tblProd .= "<tr class='w3-indigo'><th id='nummer'>Nr</th><th id='type'>Type</th><th id='product'>Product</th><th>Hoeveel</th><th>Prijs</th><th>Delete</th></tr>";

$i=0;
foreach ($array as $key => $value) {
    if ($i==0) {$i++;}
    else
    {
    $tblProd .= "<tr id='$key'><td class='nummer prodX'  contenteditable>" . $value[0] . "</td>";
    $tblProd .= "<td class='type prodX' contenteditable>" . $value[1] . "</td>";
    $tblProd .= "<td class='product prodX' contenteditable>" . $value[2] . "</td>";
    $tblProd .= "<td class='per prodX' contenteditable>" . $value[3] . "</td>";
    $tblProd .= "<td class='prijs prodX' contenteditable>" . $value[4] . "</td>";
//    $tblProd .= "<td class='save' id='" . $value[0] . "'><img src='../icons/save.png'></img></td>";
    $tblProd .= "<td class='del' id='" . $value[0] . "'><img src='../icons/delete.png'></img></td></tr>";
}}
$tblProd .= "</table>";

?>
<!DOCTYPE html>

<html>
    <head>
        <meta charset="UTF-8">
        <title></title>

        <meta name="viewport" content="width=device-width, initial-scale=1">
        <link rel="stylesheet" href="https://www.w3schools.com/w3css/4/w3.css">
         <script src="../css-js/jquery-3.6.0.js"></script>
        <script src="../css-js/table2csv.js" type="text/javascript"></script>
        <style>

            table{
                width:75vw;
            }

            .w3-container{
                width:100%;
            }
            .menu{
                background-color: #38444d;
                color: white;
                height:60px;
                display: flex;
            }

            .xtag{
                float: right;
            }

           .home{
                -webkit-filter: invert(100%);
            }
    </style>

        

    </head>
    <body>
<?php include "menu.php";?>  
        <p>Let op: nummers uniek houden, dus niet wijzigen. Geen vreemde tekens ('/\")gebruiken.</p>
             <button class='w3-btn w3-green' id='klaar1' type="button">Opslaan</button>
             <p>
                  <?php echo $tblProd ?>
                 &nbsp;<button type="button" onclick="myFunction()" class='w3-button w3-blue'>Product toevoegen</button>    
                 
             
             <button class='w3-btn w3-green' id='klaar2' type="button">Opslaan</button>
             
               <div id='output'>
                       
               </div> 

            

        <script>
            $('.del').on('click', function () {
//                $('.del').('click', function () {
                $(this).closest("tr").remove();
                id = $(this).closest('tr').attr('id');
            });

    
            function myFunction() {
                window.scrollTo(0, document.body.scrollHeight);
                var table = document.getElementById("prods");
                var row = table.insertRow(-1);
                var cell1 = row.insertCell(0);
                var cell2 = row.insertCell(1);
                var cell3 = row.insertCell(2);
                var cell4 = row.insertCell(3);
                var cell5 = row.insertCell(4);
//                var cell6 = row.insertCell(5);
                cell1.outerHTML = "<td class='nummer' contenteditable></td>";
                cell2.outerHTML = "<td class='type' contenteditable></td>";
                cell3.outerHTML = "<td class='product' contenteditable></td>";
                cell4.outerHTML = "<td class='per' contenteditable></td>";
                cell5.outerHTML = "<td class='prijs' contenteditable></td>";
//                cell6.outerHTML = "<td id='0' class='del'><img src='../icons/delete.png'></img></td></tr>";

            }

       
            

            $(document).ready(function () {
                $('[id^="klaar"]').on("click", function () {
//                    alert ('ssssss');
//                    naam = $(this).attr('id');
//                    if (confirm('Kan de hele tabel opgeslagen worden?')) {
           
     let options = {
	"separator": ";",
	"newline": "\n",
	"quoteFields": false,
	"excludeColumns": "",
	"excludeRows": "",
	"trimContent": true,
	"filename": "table.csv",
	"appendTo": "#output"
};

$('#prods').table2csv('output', options);
var res = $('#output').text();
    
     
$.ajax({
    url: "bew_product-aj.php",
    type: "GET",
    dataType: "json",
    data: {
        naam: res
    },
    success: function(test) {
        // continue program
//        alert(test);
//      $('#output').html('is nu leeg');
    },
    error: function() {
        // handle error
//            alert(log);
//            $('#output').html('is nu leeg');
    }
     
});

       history.go( - 1);
//       window.location.href = "http://kassa.venes.info";
                });
            });


        </script>

       
    </body>
</html>
