<?php

/* 
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Scripting/EmptyPHP.php to edit this template
 */

//$doc_root = $_SERVER["DOCUMENT_ROOT"]; //C:\USBWebserver v8.6\root\Kassa
//$server_url = $_SERVER["SERVER_NAME"]; //GEEFT ALLEEN LOCALHOST
define('ROOTPATH', __DIR__);  //ZELFDE ALS DOC ROOT

//define('LEDEN', ROOTPATH . "/leden/leden.txt");  //ZELFDE ALS DOC ROOT
define('BONNENPAD', ROOTPATH."/bonnen/");

//define('PADNAARDB',ROOTPATH . "/txtdatabase/db/");
//define('PADNAARCLASS',ROOTPATH . "/txtdatabase/txtdb.class.php");
//define('PADNAARCLASSORIG',ROOTPATH . "/txtdatabase/txtdb.classORIG.php");