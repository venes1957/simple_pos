<?php
require_once ("settings.php");

//============load csv in 2D array==========================================
$filename = ROOTPATH . "/admin/product.txt";
$delimiter = ";";

function csv_to_multidimension_array($filename = '', $delimiter = ',') {
    if (!file_exists($filename) || !is_readable($filename)) {
        return false;
    }

//    $header = NULL;
    $data = array();

    if (($handle = fopen($filename, 'r')) !== false) {
        while (($row = fgetcsv($handle, 1000, $delimiter)) !== false) {
            $data[] = $row;
        }
        fclose($handle);
    }
    return $data;
}

$array = csv_to_multidimension_array($filename, $delimiter);

//==================producten============================================================
function maaktabel($array, $soort, $kleur) {
    $tabel = "<div class='w3-bar'>";
    for ($i = 0; $i < count($array); $i++) {
        if ($array[$i][1] == $soort) {
            $string = $array[$i][0] . ":" . $array[$i][2] . ":" . $array[$i][4];
            $tabel .= "<button id='prod' class='bongegevens w3-cel w3-border w3-border-black w3-mobile w3-bar-item w3-button $kleur'>" . $array[$i][2] . "&nbsp;<span id='" . $string . "' class='idinfo w3-badge w3-red'></span></button>";
        }
    }
    $tabel .= "</div>";
    return $tabel;
}

$alcohol = maaktabel($array, 'alcohol', 'w3-orange');
$fris = maaktabel($array, 'fris', 'w3-teal');
$keuken = maaktabel($array, 'keuken', 'w3-blue');
$brood = maaktabel($array, 'brood', 'w3-yellow');
$actie = maaktabel($array, 'actie', 'w3-paleyellow');
$brood .= $actie;
?>


<!DOCTYPE html>

<html>
    <head>
        <meta charset="UTF-8">
        <title></title>

        <meta name="viewport" content="width=device-width, initial-scale=1">

        <link rel="stylesheet" href="css-js/w3.css">
        <script src="css-js/jquery-3.6.0.js"></script>

        <link rel="stylesheet" href="https://code.jquery.com/ui/1.11.4/themes/smoothness/jquery-ui.css">

        <script src="https://code.jquery.com/ui/1.11.4/jquery-ui.js"></script>  

        <style>

            #prod {
                width:80%;
                height:47px;
                margin-right: 4px;
                margin-left: 4px;
                margin-bottom: 4px;
                margin-top: 4px;
                font-size: 13px;
                font-weight: bold;
            }

            #top {

                height:65px;
                display: flex;
                /*align-items: center;*/
                /*justify-content: center;*/
            }

            .idinfo{
                float: right;
            }

            img {
                -webkit-filter: invert(100%);
            }

            .w3-quarter{
                /*height:100vh;*/
                min-height: -webkit-fill-available;
            }

            .box{
                width: 100%;
                height: 100%;
                position: absolute;
                top: 0;
                left: 0;
            }
            .stack-top{
                z-index: 0;
                /*margin: 10px;  for demo purpose  */
            }

        </style>

    </head>
    <body class="w3-pale-yellow">


        <div class="w3-display-container" id='top' style='background-color: #0047AB;'>
            &nbsp;       
            <a href='betaalbon.php' src="icons/betaalbon.png" style='text-decoration: none;'><img src="icons/betaalbon.png" width="50" height="50"/></a>
            <img class='w3-display-middle' src="icons/creditcard.png" id="betaal"></img>
            <a   href='/admin/index.php' style='text-decoration: none;'>
                <img class='admin w3-display-right' src="icons/setting.png" >
            </a>
        </div>

        <div class="w3-row w3-border w3-mobile">
            <div class="w3-quarter w3-container" >
                <?php
                echo $fris;
                ?>
            </div>
            <div class="w3-quarter w3-container " >
                <?php
                echo $alcohol;
                ?>
            </div>
            <div class="w3-quarter w3-container " >

                <?php
                echo $keuken;
                ?>
            </div>
            <div class="w3-quarter w3-container " >

                <?php
                echo $brood;
                ?>
            </div>
        </div>
    </div>
</div>
</div>-->


<script>

    var Arr = [];
    $("#betaal").on("click", function () {
        $('.idinfo').each(function () {
            var aantal = $(this).text();
            var id = $(this).get(0).id;  //prod info
            if (aantal !== '') {
                Arr.push(aantal + ":" + id);
            }
        });

        $.ajax({url: 'aj_directopslaan.php',
            data: {product: Arr.toString()},
            type: 'post',
            success: function () {
                window.location.href = "betalendirect.php";
            }
        });
    });

//================GETAL OPHOGEN================================================
    $(document).ready(function () {
        $(document).on('click', '#prod', function () {
            if ($(this).children().first().text() === '') {
                $(this).children().first().text('0');
            }
            var x = $(this).children().first().text();
            getal = parseInt(x) + 1;
            var nr = getal.toString();
            $(this).children().first().text(nr);

        }
        );
    });

    //klik op nummer = reset
    $(document).ready(function () {
        $('.idinfo').on('click', function () {
            $(this).text(-1); //wordt 0
        });
    });

//toevoegen van een naam / wegschrijver=========================================
    $(document).on('click', '#invoer', function () {
        naamlid = $('#newNaam').val(); //pak naam
        $('#newNaam').val(''); //pak naam
        $.post("ajax2.php",
                {
                    name: naamlid
                });
        $("#lijst").append("<span id='lid' class='w3-btn w3-white w3-border w3-border-green w3-round-xlarge'>" + naamlid + "</span>");
    });
</script>
</body>
</html>



