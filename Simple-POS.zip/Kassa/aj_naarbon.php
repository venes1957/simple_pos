<?php

/* 
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Scripting/EmptyPHP.php to edit this template
 */

//naam uit post halen
$naam=trim($_POST["naam"]);

require_once('cl_bonhandling.php');
$testObject = new cl_bonhandling();
$testObject->naarBon($naam);


