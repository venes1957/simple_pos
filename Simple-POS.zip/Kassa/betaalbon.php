<?php
$filename = "leden//wegschrijven.txt";
require_once('cl_filehandling.php');
$testObject = new cl_filehandling();
$arr = $testObject->laadFile($filename,);
$string_version = implode(',', $arr);
$wegschrijf = explode(",", $string_version);
array_push($wegschrijf, "Omzet");
?>


<!DOCTYPE html>

<html>
    <head>
        <meta charset="UTF-8">
        <title></title>

        <meta name="viewport" content="width=device-width, initial-scale=1">
        <link rel="stylesheet" href="css-js/w3.css">
        <script src="css-js/jquery-3.6.0.js"></script>

        <link rel="stylesheet" href="https://code.jquery.com/ui/1.11.4/themes/smoothness/jquery-ui.css">
        <script src="https://code.jquery.com/ui/1.11.4/jquery-ui.js"></script>  
        <style>
 
        </style>
    </head>
    <body class="w3-pale-green">




        <div class="w3-row w3-border">
            <div class="w3-half w3-container">
                <a class='w3-button w3-blue' href="\" class="w3-bar-item w3-button">Terug</a>
                <h2>Bonnen</h2>
                <table id='bons'class='w3-table-all'>
                    <th>Naam</th><th>Save</th><th>Del</th>
                    <?php
//=====================namen van files in dir bonnen ophalen, behalve bepaalde=================
                    $files = scandir('bonnen/');
                    $files = array_diff(scandir('bonnen/'), array('.', '..'));
                    $files = array_merge($files);
                    for ($i = 0; $i < count($files); $i++) {
                        $waarde = str_replace('.txt', '', $files[$i]);
                        if (!in_array($waarde, $wegschrijf)) {
                            echo "<tr><td id='naam' class='naam' contenteditable='false'>" . htmlspecialchars($waarde) . "</td><td id='save' name='" . htmlspecialchars($waarde) . "'>";
//                            . "<img  class='save' src='icons/save.png'></td><td id='del' >"
//                            . "<img class-'del' src='icons/delete.png'></td></tr>";
                        }
                    }
                    ?>
                </table>
            </div>
            <div class="w3-half w3-container">
                <h2 id="bonnaam"></h2>
                <div class="waarde"></div>
                <!--<div id="out"></div>-->
                <button class='w3-button w3-green betaal' id='betaal'>Pinbetaling</button>
                &nbsp;&nbsp;&nbsp;&nbsp;&nbsp;<button class='w3-button w3-blue' id='herreken'>Herrekenen</button>
            </div>
        </div>


        <script>
            $("#betaal").hide();
  $("#herreken").hide();
 

// /* Event listener */
//document.getElementsById("xbon").addEventListener('change', doThing);
////
/////* Function */
//function doThing(){
//   alert('Horray! Someone wrote "' + this.value + '"!');
//}


            //============selecteer lid en haal dagbon op===================================
            $(document).ready(function () {
                $("td").click(function () {
                    yz = $(this).text();
                    $('#bonnaam').text(yz);
                    getAjax(yz);
                });
            });
            function getAjax(x) {
                $.ajax({
                    url: "aj_getbon.php",
                    type: "POST",
                    cache: false,
                    data: {
                        naam: x
                    },
                    success: function (msg) {
                        $(".waarde").html(msg);
                    },
                    complete: function () {
                        $("#out").append("");
                        $("#betaal").show();
                    }
                });
            }
            ;
        </script>
        <script>

            $("#betaal").click(function () {
                myFunction();
            });

            function myFunction() {
                naam = $("#bonnaam").text();
                $.post("aj_betaal_lid.php",
                        {
                            naam: naam
                        },
                        function () {
                            document.location.href = "/";
                        });
            }


        </script>
        <script>
            $(document).on('click', 'img', function () {
                if (confirm('Weet u zeker dat dit verwijderd moet worden?')) {
                    // Save it!
                    $(this).closest("tr").remove();
                    id = $(this).closest('tr').attr('id');
                }
            });


        </script>
        <script>
            $('#herreken').on('click', function () {
                var i = 0;
                var t = document.getElementById('xbon');
                var sum=0;
                var aantal=0;
                $("#xbon tr").each(function () {
                   
                    var val1 = $(t.rows[i].cells[0]).text();
                    if (isNumeric(val1)) {
                        var quant=$(t.rows[i].cells[0]).text();
                        aantal+= quant;
                        var price=$(t.rows[i].cells[1]).text();
                        var total=quant * price;
                        $(t.rows[i].cells[3]).text(total.toFixed(2));
                        sum += total;
                        $('#xbon #xsum').text(sum.toFixed(2));
                    }

                    i++;

                function isNumeric(str) {
                    if (typeof str != "string")
                        return false // we only process strings!  
                    return !isNaN(str) && // use type coercion to parse the _entirety_ of the string (`parseFloat` alone does not do this)...
                            !isNaN(parseFloat(str)) // ...and ensure strings of whitespace fail
                }
                
                });
         });


        </script>
        
       
    </body>
</html>




