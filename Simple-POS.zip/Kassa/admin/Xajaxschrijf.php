<?php

/* 
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Scripting/EmptyPHP.php to edit this template
 */
$doc_root = $_SERVER["DOCUMENT_ROOT"];
$name= $_POST['naam'];
$filename=$doc_root."/leden/wegschrijven.txt";
file_put_contents($filename, $name);

//$req_dump = print_r($_REQUEST, true);

//$myfile = fopen("newfile.txt", "w") or die("Unable to open file!");
//$txt = "John Doe\n";
//fwrite($myfile, $txt);
////$txt = "Jane Doe\n";
////fwrite($myfile, $txt);
//fclose($myfile);


//$fp = file_put_contents('a_request.log', $req_dump);