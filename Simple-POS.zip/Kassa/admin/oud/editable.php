<?php
//
//$doc_root = $_SERVER["DOCUMENT_ROOT"];
////file_put_contents("root.txt", $doc_root); 
//
////$data="test";
//
////$fp = fopen('vardump.txt', 'w');
////fwrite($fp, serialize($_REQUEST));
////fclose($fp);
//
////ob_start();
////var_dump($_POST);
////$data = ob_get_clean();
////$fp = fopen("REQUEST.log", "w");
////fwrite($fp, $data);
////fclose($fp);
////
//file_put_contents($doc_root."/admin/request.txt", print_r($_REQUEST, true), 'a'); 
////
//file_put_contents($doc_root."/admin/test2.txt", file_get_contents('php://input'));
// 
//
//
//if(isset($_POST))
//{
// $nummer = $_POST["nummer"];
// $type = $_POST["type"];
// $product = $_POST["product"];
// $hoeveel= $_POST["hoeveel"];
// $prijs = $_POST["prijs"];
//}
// $query='';
// for($count = 0; $count < count($nummer); $count++)
// {
//  $query .= $nummer[$count].";".$type[$count].";".$product[$count].";".$hoeveel[$count].";".$prijs[$count].";".PHP_EOL;
// 
//  
// }
//// else {
////    file_put_contents("foutje.txt", 'bedankt', 'w'); 
//// }
//     
// 
//file_put_contents($doc_root."/admin/product.txt", print_r($query, true)); 
//// file_put_contents($doc_root."/admin/productx.txt", $query, 'w'); 
//
////==========================================================================
////        inladen van alle producten in een tabel      
////              
////==========================================================================


//==========================================================================
//              import txt en omzetten naar txtdb
//              
//==========================================================================
//============load csv in 2D array==========================================
//$doc_root = $_SERVER["DOCUMENT_ROOT"];
//require_once ($doc_root . "/settings.php");
////include(ROOTPATH . '/txtdatabase/txtdb.class.php');
//$filename = ROOTPATH . "/admin/product.txt";
//$delimiter = ";";
//
//
//function csv_to_multidimension_array($filename = '', $delimiter = ',') {
//    if (!file_exists($filename) || !is_readable($filename)) {
//        return false;
//    }
//
////    $header = NULL;
//    $data = array();
//
//    if (($handle = fopen($filename, 'r')) !== false) {
//        while (($row = fgetcsv($handle, 1000, $delimiter)) !== false) {
//            $data[] = $row;
//        }
//        fclose($handle);
//    }
//    return $data;
//}
//$array = csv_to_multidimension_array($filename, $delimiter);
////===========hele array inlezen=================================================================
//include(ROOTPATH . '/txtdatabase/txtdb.class.php');
//
//$i=1;
//$db = new TxtDb([
//    'dir' => ROOTPATH . '/admin/',
//    'extension' => 'txtdb',
//    'encrypt' => false,
//        ]);
//
//    foreach($array as $key => $value){
////        echo $value[0].$value[1].$value[2].$value[3].$value[4];
//
//$data = array(
//	'nummer' => $value[0],
//	'type' => $value[1],
//	'product'=> $value[2],
//	'per'	=> $value[3],
//        'prijs' => $value[4]
//);
//
//
////Insert
//$db->insert('producten',$data,$i++); //i dus niet gelijk aan prod
//
//    }
//==========================================================================
//            alle data tonen uit txtdb   
//              
//==========================================================================
//$doc_root = $_SERVER["DOCUMENT_ROOT"];
//require_once ($doc_root . "/settings.php");
//include(ROOTPATH . '/txtdatabase/txtdb.class.php');
//$csv='';
//
//$db = new TxtDb([
//    'dir' => ROOTPATH . '/admin/',
//    'extension' => 'txtdb',
//    'encrypt' => false,
//        ]);
//
//$producten = $db->select('producten');
//$prods = "<table class='w3-table-all' >";
//$prods .= "<tr class='w3-green'><th>Nr</th><th>Type</th><th>Product</th><th>Per</th><th>Prijs</th></tr>";
//foreach ($producten as $product) {
//    $prods .= '<tr><td>' . $product['nummer'] . '</td>';
//    $prods .= '<td>' . $product['type'] . '</td>';
//    $prods .= '<td>' . $product['product'] . '</td>';
//    $prods .= '<td>' . $product['per'] . '</td>';
//    $prods .= '<td>' . $product['prijs'] . '</td>';
//    $prods .= '</tr>';
//
//    $csv .= $product['nummer'] . ";" . $product['type'] . ";" . $product['product'] . ";" . $product['per'] . ";" . $product['prijs']. "\n";
//}
////$prods .= "<tr><td></td><td></td><td>Aantal:$telop</td><td>Totaal:</td><td>" . curr_format($totaal) . "</td></tr>";
//$prods .= "</table>";
//
//file_put_contents('product.txt', $csv);
//
//echo $prods;
//==========================================================================
//       wijziging wegwerken       
//              
//==========================================================================
//$fp = fopen('vardump.txt', 'w');
//fwrite($fp, print_r($_POST, TRUE));
//fclose($fp);

$doc_root = $_SERVER["DOCUMENT_ROOT"];
require_once ($doc_root . "/settings.php");
include(ROOTPATH . '/txtdatabase/txtdb.class.php');

$db = new TxtDb([
    'dir' => ROOTPATH . '/admin/',
    'extension' => 'txtdb',
    'encrypt' => false,
        ]);

if(isset($_REQUEST))
{
 $id = $_REQUEST["id"];
 $nummer = $_REQUEST["nummer"];
 $type = $_REQUEST["type"];
 $product = $_REQUEST["product"];
 $per= $_REQUEST["per"];
 $prijs = $_REQUEST["prijs"];
 

 $update = array(
	'nummer' => $nummer,
	'type'  => $type,
	'product' => $product,
	'per'	=> $per,
        'prijs'	=> $prijs
     );
$db->update('producten',$update,$id);
 
}
$producten = $db->select('producten');
foreach ($producten as $product) {
   $csv .= $product['nummer'] . ";" . $product['type'] . ";" . $product['product'] . ";" . $product['per'] . ";" . $product['prijs']. "\n";
}

file_put_contents('product.txt', $csv);

echo "De wijziging in dit product is opgeslagen!";