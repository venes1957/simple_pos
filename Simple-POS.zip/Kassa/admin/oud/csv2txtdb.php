<?php

/* 
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Scripting/EmptyPHP.php to edit this template
 */
$doc_root = $_SERVER["DOCUMENT_ROOT"];
require_once ($doc_root . "/settings.php");
include(ROOTPATH . '/txtdatabase/txtdb.class.php');


$db = new TxtDb([
    'dir' => ROOTPATH . '/admin/',
    'extension' => 'txtdb',
    'encrypt' => false,
        ]);

//=====================================================


$filename = ROOTPATH . "/admin/product.txt";
$delimiter = ";";

function csv_to_multidimension_array($filename = '', $delimiter = ',') {
    if (!file_exists($filename) || !is_readable($filename)) {
        return false;
    }

    $header = NULL;
    $data = array();

    if (($handle = fopen($filename, 'r')) !== false) {
        while (($row = fgetcsv($handle, 1000, $delimiter)) !== false) {
            $data[] = $row;
        }
        fclose($handle);
    }
    return $data;
}

$array = csv_to_multidimension_array($filename, $delimiter);

$i=1;
foreach ($array as $key => $value) {
//    {"1":{"nummer":"4","type":"fris","product":"Thee","per":"flesje","prijs":"1.99"}
   print_r($value);
//    $tblProd .= "<tr id='$key'><td class='nummer prodX'  contenteditable>" . $value[0] . "</td>";
//    $tblProd .= "<td class='type prodX' contenteditable>" . $value[1] . "</td>";
//    $tblProd .= "<td class='product prodX' contenteditable>" . $value[2] . "</td>";
//    $tblProd .= "<td class='per prodX' contenteditable>" . $value[3] . "</td>";
//    $tblProd .= "<td class='prijs prodX' contenteditable>" . $value[4] . "</td>";
//    $tblProd .= "<td class='save' id='" . $value[0] . "'><img src='../icons/save.png'></img></td>";
//    $tblProd .= "<td class='del' id='" . $value[0] . "'><img src='../icons/delete.png'></img></td></tr>";

    $data = array(
	'nummer' => $value[0],
	'type' => $value[1],
	'product' => $value[2],
	'per'	=> $value[3],
        'prijs' => $value[4]
);
 $csv .= $value[0] . ";" . $value[1] . ";" . $value[2] . ";" . $value[3] . ";" . $value[4] . "\n";
//Insert
$db->insert('producten',$data,$i++);
    
    
    
    }
file_put_contents('download.csv', $csv);