<?php

$doc_root = $_SERVER["DOCUMENT_ROOT"];
require_once ($doc_root . "/settings.php");
include(ROOTPATH . '/txtdatabase/txtdb.class.php');

$db = new TxtDb([
    'dir' => ROOTPATH . '/admin/',
    'extension' => 'txtdb',
    'encrypt' => false,
        ]);

// $fp = fopen('vardump.txt', 'w');
//fwrite($fp, print_r($_POST, TRUE));
//fclose($fp);

if(isset($_POST))
{
 $nummer = $_POST["nummer"];
 $type = $_POST["type"];
 $product = $_POST["product"];
 $per= $_POST["per"];
 $prijs = $_POST["prijs"];
 

//$welknummer = $db->select('producten',array('nummer' => $nummer));
//$xnr=array_key_first($welknummer);

$waarde = $db->select('producten');
end($waarde);         // move the internal pointer to the end of the array
$key = key($waarde);  // fetches the key of the element pointed to by the internal pointer


//
//$fp = fopen('vardump.txt', 'w');
//fwrite($fp, $key);
//fclose($fp);

$data = array(
	'nummer' => $nummer,
	'type'  => $type,
	'product' => $product,
	'per'	=> $per,
        'prijs'	=> $prijs
     );

//Insert
$db->insert('producten',$data,$key+1);
//
}

$producten = $db->select('producten');
foreach ($producten as $product) {
   $csv .= $product['nummer'] . ";" . $product['type'] . ";" . $product['product'] . ";" . $product['per'] . ";" . $product['prijs']. "\n";
}

file_put_contents('product.txt', $csv);

//echo "De wijziging in dit product is opgeslagen!";