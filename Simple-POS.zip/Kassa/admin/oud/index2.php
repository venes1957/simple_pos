<?php
/*

 */
//==========================================================================
$doc_root = $_SERVER["DOCUMENT_ROOT"];
require_once ($doc_root . "/settings.php");
include(ROOTPATH . '/txtdatabase/txtdb.class.php');
$totaal = 0;
$telop = 0;
$csv = '';
//==========================================================================
//================OMZET=========================================================
$db = new TxtDb([
    'dir' => ROOTPATH . '/txtdatabase/db/',
    'extension' => 'txtdb',
    'encrypt' => false,
        ]);

$teachers = $db->select('Omzet');
$omzet = "<table id='prodx' class='w3-table-all' >";
$omzet .= "<tr class='w3-green'><th>Datum</th><th>Product</th><th>Prijs</th><th>Aantal</th><th>Bedrag</th></tr>";

function verwijderjaar($datum) {
    //verwijder jaar
    $datum = str_replace('-2023', '', $datum);
    return $datum;
}

foreach ($teachers as $teacher) {
    $omzet .= '<tr><td>' . verwijderjaar($teacher['datum']) . '</td>';
    $omzet .= '<td>' . $teacher['product'] . '</td>';
    $omzet .= '<td>' . curr_format($teacher['prijs']) . '</td>';
    $omzet .= '<td>' . $teacher['aantal'] . '</td>';
    $omzet .= '<td>' . curr_format($teacher['prijs'] * $teacher['aantal']) . '</td>';
    $omzet .= '</tr>';

    $totaal += $teacher['prijs'] * $teacher['aantal'];
    $telop += $teacher['aantal'];
    $dag = $teacher['datum'];
    $csv .= $teacher['datum'] . ";" . $teacher['product'] . ";" . $teacher['prijs'] . ";" . $teacher['aantal'] . ";" . ($teacher['prijs'] * $teacher['aantal']) . "\n";
}
$omzet .= "<tr><td></td><td></td><td>Aantal:$telop</td><td>Totaal:</td><td>" . curr_format($totaal) . "</td></tr>";
$omzet .= "</table>";

file_put_contents('download.csv', $csv);

function curr_format($amount) {
    $ret = "€" . number_format($amount, 2, ",", " ");
    return $ret;
}

//============PRODUCTEN==================================================================
//$filename = ROOTPATH . "/admin/product.txt";
//$delimiter = ";";
//
//function csv_to_multidimension_array($filename = '', $delimiter = ',') {
//    if (!file_exists($filename) || !is_readable($filename)) {
//        return false;
//    }
//
//    $header = NULL;
//    $data = array();
//
//    if (($handle = fopen($filename, 'r')) !== false) {
//        while (($row = fgetcsv($handle, 1000, $delimiter)) !== false) {
//            $data[] = $row;
//        }
//        fclose($handle);
//    }
//    return $data;
//}
//
//$array = csv_to_multidimension_array($filename, $delimiter);
//$tblProd = "<table id='prods' class='w3-table-all' style='width: 70%;'>";
//$tblProd .= "<tr class='w3-indigo'><th>Nr</th><th>Type</th><th>Product</th><th>Hoeveel</th><th>Prijs</th><th>Save</th><th>Delete</th></tr>";
//
//foreach ($array as $key => $value) {
//    $tblProd .= "<tr id='$key'><td class='nummer prodX'  contenteditable>" . $value[0] . "</td>";
//    $tblProd .= "<td class='type prodX' contenteditable>" . $value[1] . "</td>";
//    $tblProd .= "<td class='product prodX' contenteditable>" . $value[2] . "</td>";
//    $tblProd .= "<td class='per prodX' contenteditable>" . $value[3] . "</td>";
//    $tblProd .= "<td class='prijs prodX' contenteditable>" . $value[4] . "</td>";
//    $tblProd .= "<td class='save' id='" . $value[0] . "'><img src='../icons/save.png'></img></td>";
//    $tblProd .= "<td class='del' id='" . $value[0] . "'><img src='../icons/delete.png'></img></td></tr>";
//}
//$tblProd .= "</table>";

//$doc_root = $_SERVER["DOCUMENT_ROOT"];
//require_once ($doc_root . "/settings.php");
//include(ROOTPATH . '/txtdatabase/txtdb.class.php');
//
$xc = new TxtDb([
    'dir' => ROOTPATH . '/admin/',
    'extension' => 'txtdb',
    'encrypt' => false,
        ]);

$producten = $xc->select('producten');
$tblProd = "<table id='prods' class='w3-table-all' style='width: 70%;'>";
$tblProd .= "<tr class='w3-indigo'><th>Nr</th><th>Type</th><th>Product</th><th>Hoeveel</th><th>Prijs</th><th>Save</th><th>Delete</th></tr>";

foreach ($producten as $key => $product) {
    $tblProd .= "<tr id='$key'><td class='nummer prodX'  contenteditable>" . $key . "</td>";
    $tblProd .= "<td class='type prodX' contenteditable>" . $product['type'] . "</td>";
    $tblProd .= "<td class='product prodX' contenteditable>" . $product['product'] . "</td>";
    $tblProd .= "<td class='per prodX' contenteditable>" . $product['per'] . "</td>";
    $tblProd .= "<td class='prijs prodX' contenteditable>" . $product['prijs'] . "</td>";
    $tblProd .= "<td class='save' id='" . $key . "'><img src='../icons/save.png'></img></td>";
    $tblProd .= "<td class='del' id='" . $key . "'><img src='../icons/delete.png'></img></td></tr>";
}
$tblProd .= "</table>";
//=======wegschrijven===========================================================
$tabelweg = file_get_contents(ROOTPATH . "/leden/wegschrijven.txt");
$wegschr = ltrim($tabelweg);
//==============================================================================
?>
<!DOCTYPE html>

<html>
    <head>
        <meta charset="UTF-8">
        <title></title>

        <meta name="viewport" content="width=device-width, initial-scale=1">
        <link rel="stylesheet" href="https://www.w3schools.com/w3css/4/w3.css">
        <!--<link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/4.7.0/css/font-awesome.min.css">-->

        <style>

            table{
                width:75vw;
            }

            .w3-container{
                width:100%;
            }
            .menu{
                background-color: #38444d;
                color: white;
                height:60px;
                display: flex;
            }

            .xtag{
                float: right;
            }

           .home{
                -webkit-filter: invert(100%);
            }
        </style>

        <script src="https://code.jquery.com/jquery-3.6.0.js"></script>

    </head>
    <body>
        <div class="w3-display-container w3-mobile"> 
            <!--<button onclick="history.go( - 1);" class="w3-button w3-blue">Annuleer</button>-->
            <div class='menu'>
                <div class="btn-group">
                    <a  class='back' onclick="history.go(-1);"><img class='home' src='../icons/home.png'/></a>
                    <button   id="cc1" class="w3-button w3-left-align">Omzet</button>
                    <button   id="cc2" class="w3-button w3-left-align">Product</button>
                    <button   id="cc3" class="w3-button w3-left-align">Open bonnen</button>
                    <button   id="cc4" class="w3-button w3-left-align">Schrijf</button>
                </div> 
            </div>
            <div class="cc1" >
                <h1>Omzet</h1>
                <?php echo $omzet; ?>
                <a href="download.csv"> Download CSV</a>
            </div>

            <div class="cc2" >
                <h1>Producten</h1>
                <div id='opslaan'></div>
                <!--<button id='import_data' class='w3-button w3-green'>Opslaan</button>-->
                <button type="button" onclick="myFunction()" class='w3-button w3-blue'>Product toevoegen</button>    
                <?php
                echo "<p>Let op: nummers uniek houden, dus niet wijzigen. Geen vreemde tekens ('/\")gebruiken.</p>";
                echo $tblProd;
                ?>
            </div>


            <div class="cc3" >
                <h1>Nog in te vullen</h1>    
              
            </div>


            <div class="cc4" >
                <h1>Wegschrijven</h1>  
                <p>Elke invoer op een nieuwe regel met ervoor [ en erachter ]en komma</p>
                <input type="text" id="cies" style='width:80%;' value='<?php echo $wegschr; ?>'><br><br>
                <button id='schrijfweg' class='w3-button w3-green'>Wegschrijven</button>
            </div>

        </div>
        <script>

            $('#schrijfweg').on('click', function () {
                var schrijf = $('#cies').val();
                $.post("ajaxschrijf.php", {
                    naam: schrijf});
            });

            $(document).ready(function () {
//                $('.cc1').css('display', '');
                $('[class^=cc]').css('display', 'none');
            });
            $("#cc1").on("click", function () { //dagomzet
                $('[class^=cc]').css('display', 'none');
                $('.cc1').css('display', '');
            });

            $("#cc2").on("click", function () { //producten
                $('[class^=cc]').css('display', 'none');
                $('.cc2').css('display', '');
            });
            $("#cc3").on("click", function () {
                $('[class^=cc]').css('display', 'none');
                $('.cc3').css('display', '');
            });
            $("#cc4").on("click", function () {
                $('[class^=cc]').css('display', 'none');
                $('.cc4').css('display', '');
            });
        </script>
<!--        <script>

            $(document).on('click', '#import_data', function () {

            var nummer = [];
            var type = [];
            var product = [];
            var hoeveel = [];
            var prijs = [];
            $('.nummer').each(function () {
            nummer.push($(this).text());
            });
            $('.type').each(function () {
            type.push($(this).text());
            });
            $('.product').each(function () {
            product.push($(this).text());
            });
            $('.hoeveel').each(function () {
            hoeveel.push($(this).text());
            });
            $('.prijs').each(function () {
            prijs.push($(this).text());
            });
            $.ajax({
            url: "editable.php",
                    method: "post",
                    data: {nummer: nummer, type: type, product: product, hoeveel: hoeveel, prijs: prijs},
                    success: function ()
                    {
                    $('#opslaan').html('<div class="alert alert-success">Gegevens zijn opgeslagen</div>');
                    setTimeout(function () {
                    $('#opslaan').fadeOut();
                    }, 3000);
                    }
            });
            });
        </script>-->

        <script>
            $('.del').on('click', function () {
                $(this).closest("tr").remove();
                id = $(this).closest('tr').attr('id');
//                nr=$(this).closest("tr").find(".nummer").text();
                $.ajax({
                    url: "delete.php",
                    method: "post",
                    data: {nummer: id},
                    success: function ()
                    {
                        window.scrollTo({top: 0, behavior: 'smooth'});
                        $('#opslaan').html('<div class="alert alert-success">Gegevens zijn verwijderd!</div>');
                        setTimeout(function () {
                            $('#opslaan').fadeOut();
                        }, 3000);
                    }
                });
            });

            $('body').on('click', 'td.savenieuw', function () {
                nr = $(this).closest("tr").find(".nummer").text();
                type = $(this).closest("tr").find(".type").text();
                product = $(this).closest("tr").find(".product").text();
                per = $(this).closest("tr").find(".per").text();
                prijs = $(this).closest("tr").find(".prijs").text();
                $.ajax({
                    url: "nieuwprod.php",
                    method: "post",
                    data: {nummer: nr, type: type, product: product, per: per, prijs: prijs},
                    success: function ()
                    {
                        window.scrollTo({top: 0, behavior: 'smooth'});
                        $('#opslaan').html('<div class="alert alert-success">Gegevens zijn opgeslagen</div>');
                        setTimeout(function () {
                            $('#opslaan').fadeOut();
                        }, 3000);
                    }
                });
            });


            $('.save').on('click', function () {
                id = $(this).closest('tr').attr('id');
                nr = $(this).closest("tr").find(".nummer").text();
                type = $(this).closest("tr").find(".type").text();
                product = $(this).closest("tr").find(".product").text();
                per = $(this).closest("tr").find(".per").text();
                prijs = $(this).closest("tr").find(".prijs").text();
                $.ajax({
                    url: "editable.php",
                    method: "post",
                    data: {id: id, nummer: nr, type: type, product: product, per: per, prijs: prijs},
                    success: function ()
                    {
                        window.scrollTo({top: 0, behavior: 'smooth'});
                        $('#opslaan').html('<div class="alert alert-success">Gegevens zijn opgeslagen</div>');
                        setTimeout(function () {
                            $('#opslaan').fadeOut();
                        }, 3000);
                    }
                });
            });


            function myFunction() {
                window.scrollTo(0, document.body.scrollHeight);
                var table = document.getElementById("prods");
                var row = table.insertRow(-1);
                var cell1 = row.insertCell(0);
                var cell2 = row.insertCell(1);
                var cell3 = row.insertCell(2);
                var cell4 = row.insertCell(3);
                var cell5 = row.insertCell(4);
                var cell6 = row.insertCell(5);
                cell1.outerHTML = "<td class='nummer' contenteditable></td>";
                cell2.outerHTML = "<td class='type' contenteditable></td>";
                cell3.outerHTML = "<td class='product' contenteditable></td>";
                cell4.outerHTML = "<td class='per' contenteditable></td>";
                cell5.outerHTML = "<td class='prijs' contenteditable></td>";
                cell6.outerHTML = "<td class='savenieuw'><img src='../icons/save.png'></img></td></tr>";

            }

//============selecteer lid en haal dagbon op===================================

//            $(document).ready(function () {
//                $('#list li').on('click', function () {
//                    yz = $(this).text();
//                    getAjax(yz);
//                });
//            });
//
//            function getAjax(x) {
//                $.ajax({
//                    url: "ajax3.php",
//                    type: "POST",
//                    cache: false,
//                    data: {
//                        naam: x
//                    },
//                    success: function (msg) {
//                        $(".waarde").html(msg);
//                    },
//                    complete: function () {
//                        $("#out").append("");
//                    }
//                });
//            }
//            ;

//            $(document).ready(function () {
//                $("span").on("click", function () {
//                    naam = $(this).attr('id');
//                    if (confirm('Kan deze bon geheel verwijderd worden?')) {
//                        $.post("deletefile.php",
//                                {
//                                    naam: naam
//                                });
//                        location.reload();
//                    }
//                });
//            });

//==============BONNEN.PHP PINBETALING / wegschrijven naar resultaat=======================
//            $(document).ready(function () {
//                $("#betaal").on("click", function () {
//                    event.preventDefault();
//                         yz=$(".bon").text();
//                    $.ajax({
//                        url: "pinbetaling.php",
//                        type: "POST",
//                        cache: false,
//                        data: {
//                            naam: yz
//                          },
//                        success: function (msg) {
//                            $(".waarde").html(msg);
//                            $("li:contains('"+yz+"')").remove();
//                            location.reload();
//                        },
//                        complete: function () {
//                            $("#out").append("Data is weggeschreven!");
//                        }
//                    });
//                });
//            });
//======================================================================
        </script>

    </body>
</html>
