<?php

$doc_root = $_SERVER["DOCUMENT_ROOT"];
require_once ($doc_root . "/settings.php");
include(ROOTPATH . '/txtdatabase/txtdb.class.php');

$db = new TxtDb([
    'dir' => ROOTPATH . '/admin/',
    'extension' => 'txtdb',
    'encrypt' => false,
        ]);


if(isset($_POST))
{
 $nummer = $_POST["nummer"];





//delete row
$db->delete('producten', $nummer);

}

$producten = $db->select('producten');
foreach ($producten as $product) {
   $csv .= $product['nummer'] . ";" . $product['type'] . ";" . $product['product'] . ";" . $product['per'] . ";" . $product['prijs']. "\n";
}

file_put_contents('product.txt', $csv);

