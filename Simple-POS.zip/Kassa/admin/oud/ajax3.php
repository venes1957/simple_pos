<?php

//$data = $_POST['naam'];  //$data will contain the_id
$data= str_replace("X", "", $_POST['naam']);
$doc_root = $_SERVER["DOCUMENT_ROOT"];

//$fp = fopen('vardump.txt', 'w');
//fwrite($fp, $data."::".$doc_root);
//fclose($fp);

require_once ($doc_root."/settings.php");
include($doc_root. "/txtdatabase/txtdb.class.php");


$db = new TxtDb([
    'dir' =>  $doc_root. "/txtdatabase/db/",
    'extension' => 'txtdb',
    'encrypt' => false,
        ]);
 


//$fp = fopen('vardump.txt', 'a');
//fwrite($fp, $doc_root."/settings.php".$doc_root. "/txtdatabase/txtdb.class.php");
//fclose($fp);


echo "<h1 class='bon'>".$data. '</h1>';
//Select with where situation

$teachers = $db->select($data);
echo "<table class='w3-table w3-striped w3-border'>";
echo "<th><tr><th>Product</th><th>Aantal</th><th>Prijs</th><th>Bedrag</th></tr>";
$totaal=0;
foreach ($teachers as $teacher) {
    $aantal=intval($teacher['aantal']);
    $prijs=intval($teacher['prijs']);
	echo '<tr><td>' . $teacher['product'] . '</td>';
        echo '<td>' . curr_format($prijs) . '</td>';	
        echo '<td>' . $aantal . '</td>';
        echo '<td>' . curr_format(($aantal * $prijs)) . '</td>';
        $totaal+=$prijs * $aantal;
	echo '</tr>';
}
echo "<tr><td></td><td></td><td>Totaal:</td><td>".curr_format($totaal)."</td></tr>";
echo "</table>";


function curr_format($amount){
  $ret = "€".number_format($amount, 2, ",", " ");
return $ret;
}



