<?php
$info = '';
foreach (file("../info.txt") as $regel) {
    $info .= $regel;
}
?>


<!DOCTYPE html>

<html>
    <head>
        <meta charset="UTF-8">
        <title></title>

        <meta name="viewport" content="width=device-width, initial-scale=1">
        <link rel="stylesheet" href="../css-js/w3.css">
        <script src="../css-js/jquery-3.6.0.js"></script>

        <link rel="stylesheet" href="https://code.jquery.com/ui/1.11.4/themes/smoothness/jquery-ui.css">

        <script src="https://code.jquery.com/ui/1.11.4/jquery-ui.js"></script>  


    </head>
    <body class="">
        <?php include "menu.php";
        ?>



        <div class="w3-row w3-border">
            <div class="w3-half w3-container">

                <form action="saveinfo.php" enctype="text/plain" method="post">
<!--                    <p>Name:
                        <input name="Name" type="text" id="Name" size="40" style="-webkit-box-sizing: border-box;-moz-box-sizing: border-box;box-sizing: border-box;-webkit-background-clip: padding;-moz-background-clip: padding;background-clip: padding-box;-webkit-border-radius: 0;-moz-border-radius: 0;-ms-border-radius: 0;-o-border-radius: 0;border-radius: 0;-webkit-appearance: none;background-color: white;border: 1px solid;border-color: #848484 #c1c1c1 #e1e1e1;color: black;outline: 0;margin: 0;padding: 2px 3px;text-align: left;font-size: 13px;font-family: Arial, &quot;Liberation Sans&quot;, FreeSans, sans-serif;height: 1.8em;vertical-align: top" />
                    </p>
                    <p>Vorname:
                        <input name="Vorname" type="text" id="Vorname" size="40" style="-webkit-box-sizing: border-box;-moz-box-sizing: border-box;box-sizing: border-box;-webkit-background-clip: padding;-moz-background-clip: padding;background-clip: padding-box;-webkit-border-radius: 0;-moz-border-radius: 0;-ms-border-radius: 0;-o-border-radius: 0;border-radius: 0;-webkit-appearance: none;background-color: white;border: 1px solid;border-color: #848484 #c1c1c1 #e1e1e1;color: black;outline: 0;margin: 0;padding: 2px 3px;text-align: left;font-size: 13px;font-family: Arial, &quot;Liberation Sans&quot;, FreeSans, sans-serif;height: 1.8em;vertical-align: top" />
                    </p>
                    <p>E-mail address:
                        <input name="E-mail" type="text" id="E-mail" size="40" style="-webkit-box-sizing: border-box;-moz-box-sizing: border-box;box-sizing: border-box;-webkit-background-clip: padding;-moz-background-clip: padding;background-clip: padding-box;-webkit-border-radius: 0;-moz-border-radius: 0;-ms-border-radius: 0;-o-border-radius: 0;border-radius: 0;-webkit-appearance: none;background-color: white;border: 1px solid;border-color: #848484 #c1c1c1 #e1e1e1;color: black;outline: 0;margin: 0;padding: 2px 3px;text-align: left;font-size: 13px;font-family: Arial, &quot;Liberation Sans&quot;, FreeSans, sans-serif;height: 1.8em;vertical-align: top" />
                    </p>
                    -->                    <p>Informatie op de Direct betalen pagina:
                        <textarea value=" " name="Comment" cols="55" rows="5" id="Info" style="-webkit-box-sizing: border-box;-moz-box-sizing: border-box;box-sizing: border-box;-webkit-background-clip: padding;-moz-background-clip: padding;background-clip: padding-box;-webkit-border-radius: 0;-moz-border-radius: 0;-ms-border-radius: 0;-o-border-radius: 0;border-radius: 0;-webkit-appearance: none;background-color: white;border: 1px solid;border-color: #848484 #c1c1c1 #e1e1e1;color: black;outline: 0;margin: 0;padding: 2px 3px;text-align: left;font-size: 13px;font-family: Arial, &quot;Liberation Sans&quot;, FreeSans, sans-serif;height: auto;vertical-align: top;min-height: 40px;overflow: auto;resize: vertical;width: 100%" ><?php echo $info; ?> </textarea>
                    </p>
                    <p>
                        <input type="submit" name="Submit" value="Submit" style="-webkit-appearance: none;-webkit-border-radius: 4px;-moz-border-radius: 4px;-ms-border-radius: 4px;-o-border-radius: 4px;border-radius: 4px;-webkit-background-clip: padding;-moz-background-clip: padding;background-clip: padding-box;background: #ddd url(../images/button.png?1298351022) repeat-x;background-image: linear-gradient(#fff, #ddd);border: 1px solid;border-color: #ddd #bbb #999;cursor: pointer;color: #333;display: inline-block;font: bold 12px/1.3 &quot;Helvetica Neue&quot;, Arial, &quot;Liberation Sans&quot;, FreeSans, sans-serif;outline: 0;overflow: visible;margin: 0;padding: 3px 10px;text-shadow: white 0 1px 1px;text-decoration: none;vertical-align: top;width: auto">
                    </p>
                </form>


            </div>

        </div>
        <script>
            $(document).ready(function () {
                $("form").submit(function (event) {
                    var formData = {
                        info: $("#Info").val()
//      ,
//      email: $("#email").val(),
//      superheroAlias: $("#superheroAlias").val(),
                    };

                    $.ajax({
                        type: "POST",
                        url: "info_aj.php",
                        data: formData,
                        dataType: "json",
                        encode: true
                    }).done(function (data) {
                        console.log(data);
                    });

                    event.preventDefault();
                });
            });
        </script>

    </body>
</html>




