<?php 
  
$naam ='Omzet';  //$data will contain the_id

$tabel = "<h1 class='bon w3-table-all' id='naam'>Omzet</h1>";
$tabel .= "<table class='w3-table w3-striped w3-border'>";
$tabel .= "<tr><th>Datum</th><th>Wie</th><th>Product</th><th>Prijs</th><th>Aantal</th><th>Totaal</th></tr>";
$totaal = 0;
$telop = 0;

foreach (file("../bonnen/".$naam.".txt") as $line) {
    $eenbon = explode(";", $line);
    
    $tabel .='<tr><td>'.$eenbon[0]."</td>"; //datum
    $tabel .='<td>'.$eenbon[1]."</td>"; //wie
    $tabel .= '<td>' . $eenbon[3] . '</td>'; //product
    $tabel .= '<td>' . curr_format($eenbon[5]) . '</td>'; //prijs
    $tabel .= '<td>' . $eenbon[4] . '</td>'; //aantal
    $tabel .= '<td>' . curr_format($eenbon[6]) . '</td>'; //totaal
    $totaal += $eenbon[6];
    $telop += $eenbon[4];
    $tabel .= '</tr>';
}

$tabel .= "<tr><td></td><td></td><td>Aantal:&nbsp;$telop</td><td>Totaal:&nbsp;" . curr_format($totaal) . "</td><td></td><td></td></tr>";
$tabel .= "</table> ";

function curr_format($amount) {
    if ($amount == NULL) {
        return;
    }
    $ret = "€" . number_format($amount, 2, ",", " ");
    return $ret;
}




?>


<!DOCTYPE html>

<html>
    <head>
        <meta charset="UTF-8">
        <title></title>

        <meta name="viewport" content="width=device-width, initial-scale=1">
        <link rel="stylesheet" href="../css-js/w3.css">
        <script src="../css-js/jquery-3.6.0.js"></script>

        <link rel="stylesheet" href="https://code.jquery.com/ui/1.11.4/themes/smoothness/jquery-ui.css">
        <script src="https://code.jquery.com/ui/1.11.4/jquery-ui.js"></script>  


    </head>
    <body class="">
<?php include "menu.php";

?>



        <div class="w3-row w3-border">
            <div class="w3-half w3-container">

             <?php echo $tabel;?>   
                
            </div>
            
        </div>


    </body>
</html>




