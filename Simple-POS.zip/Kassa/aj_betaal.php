<?php

/* 
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Scripting/EmptyPHP.php to edit this template
 */

//1.schrijf de gegevens bij in Omzet
//2.verwijder bestand (op naam of Direct)

$naam=filter_input(INPUT_POST, "naam");


//filter_input(INPUT_POST, 'var_name') instead of $_POST['var_name']
//filter_input_array(INPUT_POST) instead of $_POST
      

//require_once('cl_bonhandling.php');
//$testObject = new cl_bonhandling();
//$testObject->naarOmzet(trim($naam));

// $data = str_replace("Direct", $naam, file_get_contents("bonnen/Direct.txt"));
 $data = file_get_contents("bonnen/Direct.txt");
 $fp = fopen('bonnen/Omzet.txt', 'a');
 fwrite($fp, print_r($data, TRUE));
 fclose($fp);
// if ($naam ==='Direct'){unlink("bonnen/Direct.txt");}
// else {
 unlink("bonnen/Direct.txt");
// unlink("bonnen/".$naam.".txt");
 
//}