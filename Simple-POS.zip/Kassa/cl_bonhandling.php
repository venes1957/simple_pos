<?php

/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Scripting/PHPClass.php to edit this template
 */

/**
 * Description of cl_bonhandling
 *
 * @author Jos Venes
 */
class cl_bonhandling {

    function naarBon($naam){
       ///bon direct data oppakken
        //hierin naam Direct aanpassen naar correcte naam
        $data=str_replace("Direct",$naam,file_get_contents("bonnen/Direct.txt"));
        //nieuwe filenaam maken
        //file opslaan
        $fp = fopen('bonnen/'.$naam.'.txt', 'a');
        fwrite($fp, print_r($data, TRUE));
        fclose($fp);
        //bon Direct verwijderen
        unlink("bonnen/Direct.txt"); 
        
    }
    
    function naarOmzet($naam) {
//        $data = file_get_contents("bonnen/Direct.txt");
        $data = str_replace("Direct", $naam, file_get_contents("bonnen/Direct.txt"));
        $fp = fopen('bonnen/Omzet.txt', 'a');
        fwrite($fp, print_r($data, TRUE));
        fclose($fp);
        if ($naam ==='Direct'){unlink("bonnen/Direct.txt");}
        else {
        unlink("bonnen/".$naam.".txt");}
    }

    function directOpslaan($product, $naam) {
        $regel = "";

        $eenbon = explode(",", $product);
        foreach ($eenbon as $value) {
            $piece = explode(":", $value);
            if (!$piece[0] == 0) {
                $totaal = $piece[0] * $piece[3];
                $regel .= date("d-m-Y") . ";" . $naam . ";" .$piece[1] . ";" . $piece[2] . ";" . $piece[0] . ";" . $piece[3] . ";" . $totaal . "\r\n";
            }
        }
        $fp = fopen("bonnen/" . $naam . ".txt", 'a');
        fwrite($fp, print_r($regel, TRUE));
        fclose($fp);
        //aantal / prodid / product / prijs
    }

    function remove($var) {
        $var = preg_replace('/[\x00-\x1F\x80-\xFF]/', '', $var);
        return $var;
    }

    function curr_format($amount) {
        if ($amount == NULL) {
            return;
        }
        $ret = "€" . number_format($amount, 2, ",", " ");
        return $ret;
    }
}

//require_once('cl_bonhandling.php');
//$testObject = new cl_bonhandling();
//$testObject->naarOmzet("testnaam","bonnen/Direct.txt");