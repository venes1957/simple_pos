<?php
//===========================================================================
//require_once ("settings.php");

$tabel = "<h1 class='bon' id='naam'>DIRECT</h1>";
$tabel .= "<table class='w3-table w3-striped w3-border'>";
$tabel .= "<th><tr><th>Aantal</th><th>Prijs</th><th>Product</th><th>Bedrag</th></tr>";
$totaal = 0;
$telop = 0;
$info='<p>';
foreach (file("info.txt") as $regel) {
    $info.=$regel."<br>";
}
$info.="</p>";
foreach (file("bonnen/Direct.txt") as $line) {
    $eenbon = explode(";", $line);
//    03-09-2023;Direct;21;4;Hertog Jan 0.0 bier;2.00;8
    $tabel .= '<tr><td>' . $eenbon[4] . '</td>'; //product
    $tabel .= '<td>' . curr_format($eenbon[5]) . '</td>'; //prijs
    $tabel .= '<td>' . $eenbon[3] . '</td>'; //aantal
    $tabel .= '<td>' . curr_format($eenbon[6]) . '</td>'; //bedrag
    $totaal += $eenbon[6];
    $telop += $eenbon[4];
    $tabel .= '</tr>';
}

$tabel .= "<tr><td></td><td></td><td>Aantal:$telop</td><td>Totaal:" . curr_format($totaal) . "</td></tr>";
$tabel .= "</table>";

function curr_format($amount) {
    if ($amount == NULL) {
        return;
    }
    $ret = "€" . number_format($amount, 2, ",", " ");
    return $ret;
}

//=====================FILES IN FOLDER db = bestaande bonnen=======================================
//$os = array("[bestuur]", "[barcoach]", "[wedstrijdcie]", "Direct", "Omzet");
$filename = "leden//wegschrijven.txt";
require_once('cl_filehandling.php');
$testObject = new cl_filehandling();
$arr = $testObject->laadFile($filename,);
$string_version = implode(',', $arr);
$wegschrijf = explode(",", $string_version);
//array_push($wegschrijf, "Omzet");
//var_dump( $wegschrijf);

$files = scandir("bonnen/");
$files = array_diff(scandir("bonnen/"), array('.', '..'));
$files = array_merge($files);
//$add = "<li class='Xhighlight'>Direct</>";
//var_dump($files);
$add = "";
$addW = "";
for ($i = 0; $i < count($files); $i++) {
    $waarde = str_replace('.txt', '', $files[$i]);
    if (!in_array($waarde, $wegschrijf)) {
        $file = htmlspecialchars($waarde);
        $file = str_replace(".txt", "", $file);
        $add .= "<li class='Xhighlight'>" . $file . "</>";
    }
}

foreach ($wegschrijf as $value) {
    $addW .= "<li class='Xhighlight'>" . $value . "</>";
}
?>

<!DOCTYPE html>

<html>
    <head>
        <meta charset="UTF-8">
        <title></title>

        <meta name="viewport" content="width=device-width, initial-scale=1">
        <link rel="stylesheet" href="css-js/w3.css">
        <script src="css-js/jquery-3.6.0.js" type="text/javascript"></script>
        <style>
            [contenteditable] {
                outline: 0px solid transparent;
                /*}*/

                .w3-input{
                    width:200px;
                    background-color: lightblue;
                    margin-left:50px;
                }


                #html-show{
                    display: none;
                }

                #html-show:target {
                    display: block;
                }
            </style>
        </head>
        <body>


            <div class="w3-row">
                <div class="w3-container w3-twothird">
                    <!--<h2>w3-twothird</h2>-->
                    <div class="w3-row  w3-mobile">
                        <div  class='w3-twothird waarde'><?php
                            echo $tabel;
                            ?>
                            <button class='w3-button w3-green betaal' id='betaal'>Pinbetaling</button>
                            <button class='w3-button w3-blue betaal' name='' id='naarbon'>Wegschrijven naar bon</button>
                            <button class="w3-button w3-red" id='annuleer'>Annuleer</button>
                        </div>      


                        <div id="result"></div>
                    </div>
                 <?php echo $info;?>
                </div>

                <div class="w3-container w3-third">
                    <h2>Bonnen</h2>
                    <button id="verbergnamen" class='w3-btn w3-white w3-border w3-border-blue w3-round'>Leden</button>
                    <div id='bovenaan'>
                        <input class="w3-input w3-border" type="text" id="txt_name" placeholder='Voer naam in en [Enter]' value=""> 
                        <ol class='w3-ul w3-border'>
                            <div id='div2' class='waarde'><?php echo $add; ?></div>
                        </ol>
                    </div>
                    <p>
                  
                    <button id="verberg" class='w3-btn w3-white w3-border w3-border-blue w3-round'>Intern</button>


                    <div class='weg'>
                        <ol class='w3-ul w3-border'>
                            <div id='div3' class='waarde'><?php echo $addW; ?></div>
                        </ol>
        
                    </div>
                </div>

                <script>
                    //==============PINBETALING / wegschrijven naar resultaat=======================
                    $(document).ready(function () {
                        $("#betaal").on("click", function () {
                            naam = $(".bon").text();
                            $.post("aj_betaal.php",
                                    {
                                        naam: naam
                                    },
                                    function () {
//                                    location.reload();
                                        document.location.href = "/";
                                    });

                        });
                    });

                    $(document).ready(function () {
                        $("#annuleer").on("click", function () {
//                            naam = $(".bon").text();
                            $.post("aj_deletedirect.php",
                                    function () {
                                        location.reload();
                                        document.location.href = "/";
                                    });
                        });
                    });

                    $(document).ready(function () {
                        $("#naarbon").on("click", function () {
                            //ajax - bon direct naar naam
                            naam = $('#naam').text();
                            $.ajax({url: 'aj_naarbon.php',
                                data: {naam: naam},
                                type: 'post',
                                success: function () {
                                    location.reload();
                                    document.location.href = "/";
                                }
                            });

                        });
                    });

                    //======================================================================

                    $(document).ready(function () {
                        $('#txt_name').keydown(function (event) {
                            if (event.which === 13) {
                                $("#div2").append("<li id='nieuw' class='Xhighlight'>" + $('#txt_name').val() + "</>");
                                $('#txt_name').val('');
                                $("li#nieuw").trigger("click");

                            }
                        });
                    });

                    $('#div3, #div2').on('click', 'li', function () {
                        naam = $(this).text();
                        $('#naam').text(naam);
                        document.getElementById("naarbon").name = naam;
                        $('#naarbon').show();
                         $('#bovenaan').hide();
                         $('#verbergnamen').show();
                         //verberg knop pinbetaling
                         var b= 'Direct';
                         if (naam === b) {$("#betaal").show();}else{
    // code to be executed if condition is true
    $("#betaal").hide();
} 
                        
                    });


                    $(document).ready(function () {
                        $('#naarbon').hide();
                        $('.weg').hide();
                         $('#verbergnamen').hide();

                    });

                    $(function () {
                        $('#verberg').click(function () {
                            $('.weg').toggle();
                        });
                    });
                    
                    $(function () {
                        $('#verbergnamen').click(function () {
                            $('#bovenaan').show();
                        });
                    });
                </script>

        </body>
    </html>